import React from 'react';
import { StatusBar, useColorScheme } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { MenuProvider } from '../shared/providers/MenuProvider';
import { AppNavigator } from '../navigation/AppNavigator';

const App = () => {
  const isDark = useColorScheme() === 'dark';
  return (
    <SafeAreaProvider>
      <MenuProvider>
        <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} />
        <AppNavigator />
      </MenuProvider>
    </SafeAreaProvider>
  );
};

export default App;
