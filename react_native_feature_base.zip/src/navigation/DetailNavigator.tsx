import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import DetailCardScreen from '../features/cards/screens/DetailCardScreen';
import InfoDetailScreen from '../features/cards/screens/InfoDetailScreen';
import ShopCardScreen from '../features/cards/screens/ShopCardScreen';
import { CustomHeader } from '../shared/components/CustomHeader';

export type DetailStackParamList = {
  DetailCard: undefined;
  InfoDetail: undefined;
  ShopCard: undefined;
};

const Stack = createNativeStackNavigator<DetailStackParamList>();

const DetailNavigator = () => {
  return (
    <Stack.Navigator screenOptions={{ header: (p) => <CustomHeader {...p} /> }}>
      <Stack.Screen name="DetailCard" component={DetailCardScreen} options={{ title: 'Detail Card' }} />
      <Stack.Screen name="InfoDetail" component={InfoDetailScreen} options={{ title: 'Info Detail' }} />
      <Stack.Screen name="ShopCard" component={ShopCardScreen} options={{ title: 'Shop Card' }} />
    </Stack.Navigator>
  );
};

export default DetailNavigator;
