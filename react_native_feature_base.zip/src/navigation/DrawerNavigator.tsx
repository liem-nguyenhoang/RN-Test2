import React from 'react';
import { createDrawerNavigator, DrawerContentScrollView } from '@react-navigation/drawer';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import HomeScreen from '../features/home/screens/HomeScreen';
import ListCardScreen from '../features/cards/screens/ListCardScreen';
import PolicyScreen from '../features/policy/screens/PolicyScreen';
import TermsScreen from '../features/auth/screens/TermsScreen';
import { CustomHeader } from '../shared/components/CustomHeader';
import { COLORS } from '../shared/styles/theme';

const Drawer = createDrawerNavigator();

function CustomDrawerContent(props: any) {
  const { navigation, state } = props;
  const insets = useSafeAreaInsets();
  const currentRoute = state.routeNames[state.index];

  const DrawerItem = ({ label, icon, routeName, onPress }: any) => {
    const active = currentRoute === routeName;
    return (
      <TouchableOpacity style={styles.drawerItem} onPress={onPress}>
        <Icon name={icon} size={22} color={active ? COLORS.primary : COLORS.text} />
        <Text style={[styles.drawerText, { color: active ? COLORS.primary : COLORS.text }]}>{label}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <DrawerContentScrollView {...props} contentContainerStyle={{ paddingTop: insets.top + 10 }}>
      <DrawerItem label="Home" icon="home" routeName="Home" onPress={() => navigation.navigate('Home')} />
      <DrawerItem label="List Card" icon="list" routeName="ListCard" onPress={() => navigation.navigate('ListCard')} />
      <DrawerItem label="Policy" icon="gavel" routeName="Policy" onPress={() => navigation.navigate('Policy')} />
      <DrawerItem label="Terms" icon="description" routeName="Terms" onPress={() => navigation.navigate('Terms')} />
      <TouchableOpacity style={styles.drawerItem} onPress={() => navigation.replace('Login')}>
        <Icon name="logout" size={22} color="red" />
        <Text style={[styles.drawerText, { color: 'red' }]}>Logout</Text>
      </TouchableOpacity>
    </DrawerContentScrollView>
  );
}

export const DrawerNavigator: React.FC<any> = ({ navigation }) => {
  return (
    <Drawer.Navigator screenOptions={{ header: (props) => <CustomHeader {...props} /> }} drawerContent={(props) => <CustomDrawerContent {...props} />}>
      <Drawer.Screen name="Home" component={HomeScreen} />
      <Drawer.Screen name="ListCard" component={ListCardScreen} />
      <Drawer.Screen name="Policy" component={PolicyScreen} />
      <Drawer.Screen name="Terms" component={TermsScreen} />
    </Drawer.Navigator>
  );
};

const styles = StyleSheet.create({
  drawerItem: { flexDirection: 'row', alignItems: 'center', padding: 12 },
  drawerText: { fontSize: 16, marginLeft: 10 },
});

export default DrawerNavigator;
