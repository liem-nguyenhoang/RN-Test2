import React from 'react';
import { NavigationContainer, useNavigationContainerRef } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { CustomHeader } from '../shared/components/CustomHeader';
import DrawerNavigator from './DrawerNavigator';
import LoginScreen from '../features/auth/screens/LoginScreen';
import TwoFAScreen from '../features/auth/screens/TwoFAScreen';
import TermsScreen from '../features/auth/screens/TermsScreen';
import DetailNavigator from './DetailNavigator';
import ProfileScreen from '../features/profile/screens/ProfileScreen';
import SettingScreen from '../features/setting/screens/SettingScreen';
import type { RootStackParamList } from '../shared/types/navigation';

const Stack = createNativeStackNavigator<RootStackParamList>();

export const AppNavigator = () => {
  const navigationRef = useNavigationContainerRef();
  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator screenOptions={{ header: (p) => <CustomHeader {...p} /> }}>
        <Stack.Screen name="Login" component={LoginScreen} options={{ title: 'Login' }} />
        <Stack.Screen name="TwoFA" component={TwoFAScreen} options={{ title: 'TwoFA' }} />
        <Stack.Screen name="Terms" component={TermsScreen} options={{ title: 'Terms' }} />
        <Stack.Screen name="AppDrawer" component={DrawerNavigator as any} options={{ headerShown: false }} />
        <Stack.Screen name="DetailFlow" component={DetailNavigator} options={{ headerShown: false }} />
        <Stack.Screen name="Profile" component={ProfileScreen} options={{ title: 'Profile' }} />
        <Stack.Screen name="Setting" component={SettingScreen} options={{ title: 'Setting' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;
