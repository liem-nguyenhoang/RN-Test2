# Clean Code Users Feature (RN + TypeORM + SQLite)

- API ở `src/common/api/*` (dùng chung mọi feature)
- SQLite/TypeORM query **chỉ** ở `src/features/users/sqlite.ts`
- UseCase điều phối online/offline: `src/features/users/services/UsersUseCase.ts`
- Incremental Sync: `src/features/users/services/SyncService.ts`
- Zustand Store: `src/features/users/store/usersStore.ts`
- Demo screen: `src/features/users/screens/UsersListScreen.tsx`

## Cài đặt nhanh
```bash
npm i
# Cho RN project thật: thêm các lib vào app của bạn
# iOS: cd ios && pod install && cd ..
```

## Lưu ý
- Bổ sung endpoint thật trong `src/common/config/appConfig.ts`
- Tất cả endpoint chỉ định nghĩa ở `common/api`. Feature **không** tự tạo endpoint.
- DB migrations nằm ở `common/db/migrations`. Import reflect-metadata đã có trong `connection`.
