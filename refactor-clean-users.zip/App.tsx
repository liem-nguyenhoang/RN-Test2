import React, { useEffect, useState } from 'react';
import { SafeAreaView, StatusBar, ActivityIndicator, View, Text } from 'react-native';
import { ensureDbReady } from './src/common/db/connection';
import { UsersListScreen } from './src/features/users/screens/UsersListScreen';

export default function App() {
  const [ready, setReady] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        await ensureDbReady();
        setReady(true);
      } catch (e: any) {
        setErr(e?.message ?? String(e));
      }
    })();
  }, []);

  if (!ready) {
    return (
      <SafeAreaView style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        {!err ? (
          <>
            <ActivityIndicator />
            <Text style={{ marginTop: 8 }}>Preparing local database…</Text>
          </>
        ) : (
          <View style={{ padding: 16 }}>
            <Text style={{ color: 'red', fontWeight: '700' }}>DB Error</Text>
            <Text>{err}</Text>
          </View>
        )}
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
      <StatusBar barStyle="dark-content" />
      <UsersListScreen />
    </SafeAreaView>
  );
}
