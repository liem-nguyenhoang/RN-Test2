import React, { useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity } from 'react-native';
import { useUsersStore, PER_PAGE_OPTIONS } from '../store/usersStore';

export function UsersListScreen() {
  const { items, total, page, perPage, loading, error, fetch, nextPage, prevPage, setPerPage } = useUsersStore();

  useEffect(() => { fetch(); }, []);

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontSize: 18, fontWeight: '600', marginBottom: 8 }}>Users ({total})</Text>
      <View style={{ flexDirection: 'row', marginBottom: 8 }}>
        {PER_PAGE_OPTIONS.map((n) => (
          <TouchableOpacity key={n} onPress={() => setPerPage(n)} style={{ padding: 8, marginRight: 8, borderWidth: 1, borderColor: perPage===n ? '#333' : '#ccc', borderRadius: 6 }}>
            <Text>{n}/page</Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading ? <Text>Loading…</Text> : null}
      {error ? <Text style={{ color: 'red' }}>{error}</Text> : null}

      <FlatList
        data={items}
        keyExtractor={(it) => String(it.id)}
        renderItem={({ item }) => (
          <View style={{ paddingVertical: 8, borderBottomWidth: 1, borderColor: '#eee' }}>
            <Text style={{ fontWeight: '600' }}>{item.name} — {item.companyName}</Text>
            <Text>{item.email}</Text>
            <Text>{item.address}</Text>
          </View>
        )}
        style={{ flex: 1 }}
      />

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12 }}>
        <TouchableOpacity onPress={prevPage} style={{ padding: 10, backgroundColor: '#eee', borderRadius: 6 }}>
          <Text>Previous</Text>
        </TouchableOpacity>
        <Text>Page {page}</Text>
        <TouchableOpacity onPress={nextPage} style={{ padding: 10, backgroundColor: '#eee', borderRadius: 6 }}>
          <Text>Next</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
