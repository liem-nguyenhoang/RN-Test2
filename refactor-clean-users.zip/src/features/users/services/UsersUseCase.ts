import { isOnline } from '../net';
import { usersSearchApi } from '../../../common/api/usersApi';
import { companiesByIdsApi } from '../../../common/api/companiesApi';
import { toUserItemVM } from '../mappers/dtoToVm';
import { searchUsersOfflineJoin } from '../sqlite';
import type { FetchParams, FetchResult } from '../repository/types';

export async function searchUsersUseCase(
  params: FetchParams,
  opts?: { signal?: AbortSignal }
): Promise<FetchResult> {
  if (!(await isOnline())) return searchUsersOfflineJoin(params);

  const { items: users, total } = await usersSearchApi({
    page: params.page,
    perPage: params.perPage,
    filters: {
      name: params.filters.name || undefined,
      address: params.filters.address || undefined,
      email: params.filters.email || undefined,
      companyId: params.filters.companyId ?? undefined,
      sortBy: params.filters.sortBy,
      sortOrder: params.filters.sortOrder,
    },
  }, opts?.signal);

  const companyIds = Array.from(new Set(users.map(u => u.companyId)));
  const companies = companyIds.length ? await companiesByIdsApi({ ids: companyIds }, opts?.signal) : [];
  return { items: toUserItemVM(users, companies), total };
}
