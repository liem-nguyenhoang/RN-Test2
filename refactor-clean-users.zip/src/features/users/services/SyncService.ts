import { getMeta, setMeta } from '../../../common/db/meta';
import { companiesChangesApi } from '../../../common/api/companiesApi';
import { usersChangesApi } from '../../../common/api/usersApi';
import { AppDataSource } from '../../../common/db/connection';
import { Company as CompanyEntity } from '../../../common/entities/Company';
import { User as UserEntity } from '../../../common/entities/User';

const META_COMPANIES = 'companies_last_sync_at';
const META_USERS     = 'users_last_sync_at';
const DEFAULT_SINCE  = '1970-01-01T00:00:00.000Z';
const CHUNK          = 300;

export class SyncService {
  async syncOnce(signal?: AbortSignal) {
    // Companies
    {
      const since = (await getMeta(META_COMPANIES)) ?? DEFAULT_SINCE;
      let page = 1, hasMore = true, maxSeen = since;
      while (hasMore) {
        const r = await companiesChangesApi({ since, page, perPage: CHUNK }, signal);
        if (r.items?.length) {
          await AppDataSource.transaction(async (m) => {
            await m.getRepository(CompanyEntity).save(r.items.map(x => Object.assign(new CompanyEntity(), x)));
          });
          if (r.maxUpdatedAt && r.maxUpdatedAt > maxSeen) maxSeen = r.maxUpdatedAt;
        }
        hasMore = !!r.hasMore; page = r.nextPage ?? (page + 1);
      }
      await setMeta(META_COMPANIES, maxSeen);
    }
    // Users
    {
      const since = (await getMeta(META_USERS)) ?? DEFAULT_SINCE;
      let page = 1, hasMore = true, maxSeen = since;
      while (hasMore) {
        const r = await usersChangesApi({ since, page, perPage: CHUNK }, signal);
        if (r.items?.length) {
          await AppDataSource.transaction(async (m) => {
            await m.getRepository(UserEntity).save(r.items.map(x => Object.assign(new UserEntity(), x)));
          });
          if (r.maxUpdatedAt && r.maxUpdatedAt > maxSeen) maxSeen = r.maxUpdatedAt;
        }
        hasMore = !!r.hasMore; page = r.nextPage ?? (page + 1);
      }
      await setMeta(META_USERS, maxSeen);
    }
  }
}
