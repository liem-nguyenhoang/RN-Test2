import type { Filters } from '../repository/types';

export const DEFAULT_FILTERS: Filters = {
  name: '', address: '', email: '', companyId: null, sortBy: 'name', sortOrder: 'asc',
};

export const PAGE_SIZE_OPTIONS = [20, 50, 100] as const;

export const ERROR_TEXT = {
  offlineFallback: (msg?: string) => `Online lỗi${msg ? ` (${msg})` : ''} — đang dùng dữ liệu offline`,
};
