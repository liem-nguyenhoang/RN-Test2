import { API_BASE_URL } from '../config/appConfig';

export class HttpError extends Error {
  constructor(message: string, public status?: number, public body?: unknown) {
    super(message);
  }
}

export async function httpJson<T>(
  path: string,
  options?: { method?: 'GET'|'POST'|'PUT'|'PATCH'|'DELETE'; body?: unknown; signal?: AbortSignal }
): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: options?.method ?? 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: options?.body ? JSON.stringify(options.body) : undefined,
    signal: options?.signal,
  });
  let data: any = null;
  try { data = await res.json(); } catch {}
  if (!res.ok) throw new HttpError(`HTTP ${res.status} @ ${path}`, res.status, data);
  return data as T;
}
