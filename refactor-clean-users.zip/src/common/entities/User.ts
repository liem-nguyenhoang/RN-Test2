import { Entity, PrimaryGeneratedColumn, Column, Index } from 'typeorm';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('increment') id!: number;
  @Index() @Column('text') name!: string;
  @Index() @Column('text') email!: string;
  @Index() @Column('text') address!: string;
  @Index() @Column('integer') companyId!: number;
  @Index() @Column('text') updatedAt!: string;
  @Index() @Column('text', { nullable: true }) deletedAt!: string | null;
}
