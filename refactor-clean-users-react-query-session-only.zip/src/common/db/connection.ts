import 'reflect-metadata';
import { DataSource } from 'typeorm';
import SQLite from 'react-native-sqlite-storage';
import { User } from '../entities/User';
import { Company } from '../entities/Company';
import { LocalMeta } from '../entities/LocalMeta';
import { InitUsersCompaniesMeta1700000000000 } from './migrations/1700000000000-InitUsersCompaniesMeta';

SQLite.enablePromise(true);

export const AppDataSource = new DataSource({
  type: 'react-native',
  database: 'app.db',
  location: 'default',
  driver: SQLite,
  logging: ['error', 'warn'],
  synchronize: false,
  entities: [User, Company, LocalMeta],
  migrations: [InitUsersCompaniesMeta1700000000000],
});

export async function ensureDbReady() {
  if (!AppDataSource.isInitialized) {
    await AppDataSource.initialize();
    await AppDataSource.runMigrations();
  }
  return AppDataSource;
}
