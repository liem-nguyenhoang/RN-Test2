import { MigrationInterface, QueryRunner } from 'typeorm';

export class InitUsersCompaniesMeta1700000000000 implements MigrationInterface {
  name = 'InitUsersCompaniesMeta1700000000000';

  public async up(q: QueryRunner): Promise<void> {
    await q.query(`
      CREATE TABLE IF NOT EXISTS "companies"(
        "id" integer PRIMARY KEY AUTOINCREMENT NOT NULL,
        "name" text NOT NULL,
        "updatedAt" text,
        "deletedAt" text
      );
    `);
    await q.query(`CREATE INDEX IF NOT EXISTS "IDX_companies_name" ON "companies" ("name");`);
    await q.query(`CREATE INDEX IF NOT EXISTS "IDX_companies_updatedAt" ON "companies" ("updatedAt");`);
    await q.query(`CREATE INDEX IF NOT EXISTS "IDX_companies_deletedAt" ON "companies" ("deletedAt");`);

    await q.query(`
      CREATE TABLE IF NOT EXISTS "users"(
        "id" integer PRIMARY KEY AUTOINCREMENT NOT NULL,
        "name" text NOT NULL,
        "email" text NOT NULL,
        "address" text NOT NULL,
        "companyId" integer NOT NULL,
        "updatedAt" text NOT NULL,
        "deletedAt" text
      );
    `);
    await q.query(`CREATE INDEX IF NOT EXISTS "IDX_users_name" ON "users" ("name");`);
    await q.query(`CREATE INDEX IF NOT EXISTS "IDX_users_email" ON "users" ("email");`);
    await q.query(`CREATE INDEX IF NOT EXISTS "IDX_users_address" ON "users" ("address");`);
    await q.query(`CREATE INDEX IF NOT EXISTS "IDX_users_companyId" ON "users" ("companyId");`);
    await q.query(`CREATE INDEX IF NOT EXISTS "IDX_users_updatedAt" ON "users" ("updatedAt");`);
    await q.query(`CREATE INDEX IF NOT EXISTS "IDX_users_deletedAt" ON "users" ("deletedAt");`);

    await q.query(`
      CREATE TABLE IF NOT EXISTS "local_meta"(
        "key" text PRIMARY KEY NOT NULL,
        "value" text NOT NULL
      );
    `);
  }

  public async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP TABLE IF EXISTS "local_meta";`);
    await q.query(`DROP INDEX IF EXISTS "IDX_users_deletedAt";`);
    await q.query(`DROP INDEX IF EXISTS "IDX_users_updatedAt";`);
    await q.query(`DROP INDEX IF EXISTS "IDX_users_companyId";`);
    await q.query(`DROP INDEX IF EXISTS "IDX_users_address";`);
    await q.query(`DROP INDEX IF EXISTS "IDX_users_email";`);
    await q.query(`DROP INDEX IF EXISTS "IDX_users_name";`);
    await q.query(`DROP TABLE IF EXISTS "users";`);
    await q.query(`DROP INDEX IF EXISTS "IDX_companies_deletedAt";`);
    await q.query(`DROP INDEX IF EXISTS "IDX_companies_updatedAt";`);
    await q.query(`DROP INDEX IF EXISTS "IDX_companies_name";`);
    await q.query(`DROP TABLE IF EXISTS "companies";`);
  }
}
