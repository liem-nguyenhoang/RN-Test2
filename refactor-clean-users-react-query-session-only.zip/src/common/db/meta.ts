import { AppDataSource } from './connection';
import { LocalMeta } from '../entities/LocalMeta';

export async function getMeta(key: string): Promise<string | null> {
  const repo = AppDataSource.getRepository(LocalMeta);
  const row = await repo.findOne({ where: { key } });
  return row?.value ?? null;
}

export async function setMeta(key: string, value: string): Promise<void> {
  const repo = AppDataSource.getRepository(LocalMeta);
  await repo.save({ key, value });
}
