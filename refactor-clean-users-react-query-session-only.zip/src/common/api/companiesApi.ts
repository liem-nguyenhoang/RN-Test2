import { httpJson } from './httpClient';

export type CompanyRowDto = { id:number; name:string; updatedAt:string|null; deletedAt:string|null };

export function companiesByIdsApi(body: { ids:number[] }, signal?: AbortSignal) {
  return httpJson<CompanyRowDto[]>('/companies/by-ids', { method: 'POST', body, signal });
}

export type CompaniesChangesRes = { items: CompanyRowDto[]; hasMore:boolean; nextPage:number|null; maxUpdatedAt:string|null };
export function companiesChangesApi(body: { since:string; page:number; perPage:number }, signal?: AbortSignal) {
  return httpJson<CompaniesChangesRes>('/companies/changes', { method: 'POST', body, signal });
}
