import { httpJson } from './httpClient';

export type UsersSearchDto = {
  page: number; perPage: number;
  filters: { name?: string; address?: string; email?: string; companyId?: number|null; sortBy?: 'name'|'address'|'company'; sortOrder?: 'asc'|'desc' };
};

export type UserRowDto = { id:number; name:string; email:string; address:string; companyId:number; updatedAt:string; deletedAt:string|null };
export type UsersSearchRes = { items: UserRowDto[]; total: number };

export function usersSearchApi(body: UsersSearchDto, signal?: AbortSignal) {
  return httpJson<UsersSearchRes>('/users/search', { method: 'POST', body, signal });
}

export type UsersChangesRes = { items: UserRowDto[]; hasMore:boolean; nextPage:number|null; maxUpdatedAt:string|null };
export function usersChangesApi(body: { since:string; page:number; perPage:number }, signal?: AbortSignal) {
  return httpJson<UsersChangesRes>('/users/changes', { method: 'POST', body, signal });
}
