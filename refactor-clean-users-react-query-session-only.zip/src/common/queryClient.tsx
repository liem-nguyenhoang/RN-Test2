import React, { useEffect } from 'react';
import { AppState } from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import { QueryClient, QueryClientProvider, onlineManager, focusManager } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30 * 1000,
      gcTime: 60 * 60 * 1000, // 1h in-memory
      refetchOnWindowFocus: true,
      refetchOnReconnect: true,
      retry: 1,
      placeholderData: (prev) => prev, // keepPreviousData-like
    },
  },
});

// Hook up React Query onlineManager with NetInfo
onlineManager.setEventListener((setOnline) => {
  const unsubscribe = NetInfo.addEventListener((state) => {
    const online = !!(state.isConnected && state.isInternetReachable);
    setOnline(online);
  });
  return unsubscribe;
});

// Hook up focusManager with AppState
function onAppStateChange(status: string) {
  focusManager.setFocused(status === 'active');
}

export function AppQueryProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    const sub = AppState.addEventListener('change', onAppStateChange);
    return () => sub.remove();
  }, []);

  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>;
}
