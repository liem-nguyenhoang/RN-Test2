import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity('local_meta')
export class LocalMeta {
  @PrimaryColumn('text') key!: string;
  @Column('text') value!: string;
}
