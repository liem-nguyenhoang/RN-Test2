import { Entity, PrimaryGeneratedColumn, Column, Index } from 'typeorm';

@Entity('companies')
export class Company {
  @PrimaryGeneratedColumn('increment') id!: number;
  @Index() @Column('text') name!: string;
  @Index() @Column('text', { nullable: true }) updatedAt!: string | null;
  @Index() @Column('text', { nullable: true }) deletedAt!: string | null;
}
