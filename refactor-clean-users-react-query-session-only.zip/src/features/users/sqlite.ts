import { AppDataSource } from '../../common/db/connection';
import { User as UserEntity } from '../../common/entities/User';
import { Company as CompanyEntity } from '../../common/entities/Company';
import type { FetchParams, FetchResult, UserItemVM } from './repository/types';

function normalizeOrder(order?: string): 'ASC'|'DESC' {
  return (order ?? 'asc').toUpperCase() === 'DESC' ? 'DESC' : 'ASC';
}

function applyFilters(qb: any, filters: FetchParams['filters']) {
  qb.where('u.deletedAt IS NULL');
  if (filters.name)    qb.andWhere('LOWER(u.name) LIKE :n', { n: `%${filters.name.toLowerCase()}%` });
  if (filters.address) qb.andWhere('LOWER(u.address) LIKE :a', { a: `%${filters.address.toLowerCase()}%` });
  if (filters.email)   qb.andWhere('LOWER(u.email) LIKE :e', { e: `%${filters.email.toLowerCase()}%` });
  if (filters.companyId !== null) qb.andWhere('u.companyId = :cid', { cid: filters.companyId });
}

function applySortOnIdQb(idQb: any, filters: FetchParams['filters']) {
  const order = normalizeOrder(filters.sortOrder);
  if (filters.sortBy === 'company') idQb.orderBy('c.name', order);
  else if (filters.sortBy === 'address') idQb.orderBy('u.address', order);
  else idQb.orderBy('u.name', order);
}

export async function searchUsersOfflineJoin(params: FetchParams): Promise<FetchResult> {
  const { page, perPage, filters } = params;
  const userRepo = AppDataSource.getRepository(UserEntity);

  const idQb = userRepo.createQueryBuilder('u')
    .select('u.id', 'id')
    .innerJoin(CompanyEntity, 'c', 'c.id = u.companyId AND c.deletedAt IS NULL');

  applyFilters(idQb, filters);
  applySortOnIdQb(idQb, filters);

  idQb.skip((page - 1) * perPage).take(perPage);
  const rows = await idQb.getRawMany<{ id:number }>();
  const ids = rows.map(r => r.id);
  if (!ids.length) return { items: [], total: 0 };

  const listQb = userRepo.createQueryBuilder('u')
    .innerJoin(CompanyEntity, 'c', 'c.id = u.companyId AND c.deletedAt IS NULL')
    .select([
      'u.id AS id','u.name AS name','u.email AS email','u.address AS address',
      'u.companyId AS companyId','c.name AS companyName',
    ])
    .where('u.id IN (:...ids)', { ids });

  const orderCase = ids.map((id, i) => `WHEN ${id} THEN ${i}`).join(' ');
  listQb.orderBy(`CASE u.id ${orderCase} END`);
  const fullRows = await listQb.getRawMany();

  const countQb = userRepo.createQueryBuilder('u')
    .innerJoin(CompanyEntity, 'c', 'c.id = u.companyId AND c.deletedAt IS NULL')
    .select('COUNT(DISTINCT u.id)', 'cnt');
  applyFilters(countQb, filters);
  const { cnt } = await countQb.getRawOne<{ cnt:number }>() ?? { cnt: 0 };

  const items: UserItemVM[] = fullRows.map(r => ({
    id: r.id, name: r.name, email: r.email, address: r.address,
    companyId: r.companyId, companyName: r.companyName,
  }));
  return { items, total: Number(cnt) };
}
