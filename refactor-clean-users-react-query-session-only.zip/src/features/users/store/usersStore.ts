import { create } from 'zustand';
import { isOnline } from '../net';
import { SyncService } from '../services/SyncService';
import { searchUsersUseCase } from '../services/UsersUseCase';
import { DEFAULT_FILTERS, PAGE_SIZE_OPTIONS } from './constants';
import type { Filters, UserItemVM } from '../repository/types';

type State = {
  items: UserItemVM[];
  total: number;
  page: number;
  perPage: number;
  filters: Filters;
  loading: boolean;
  error: string | null;
  _abort?: AbortController;
};

type Actions = {
  fetch: () => Promise<void>;
  setPerPage: (n: number) => Promise<void>;
  nextPage: () => Promise<void>;
  prevPage: () => Promise<void>;
  applyFilters: (f: Filters) => Promise<void>;
  resetFilters: () => void;
};

export const PER_PAGE_OPTIONS = PAGE_SIZE_OPTIONS;
const syncService = new SyncService();

export const useUsersStore = create<State & Actions>((set, get) => ({
  items: [], total: 0, page: 1, perPage: 20, filters: { ...DEFAULT_FILTERS }, loading: false, error: null,

  async fetch() {
    const { page, perPage, filters, _abort } = get();
    _abort?.abort();
    const ac = new AbortController();
    set({ loading: true, error: null, _abort: ac });
    try {
      const { items, total } = await searchUsersUseCase({ page, perPage, filters }, { signal: ac.signal });
      if (await isOnline()) syncService.syncOnce().catch(e => console.warn('Sync failed:', e));
      set({ items, total, loading: false, _abort: undefined });
    } catch (e: any) {
      if (e?.name === 'AbortError') return;
      set({ loading: false, error: e?.message ?? 'Lỗi tải dữ liệu', _abort: undefined });
    }
  },

  async setPerPage(n) { set({ perPage: n, page: 1 }); await get().fetch(); },
  async nextPage() {
    const { page, total, perPage } = get();
    const last = Math.max(1, Math.ceil(total / perPage));
    if (page < last) { set({ page: page + 1 }); await get().fetch(); }
  },
  async prevPage() {
    const { page } = get();
    if (page > 1) { set({ page: page - 1 }); await get().fetch(); }
  },
  async applyFilters(f) { set({ filters: f, page: 1 }); await get().fetch(); },
  resetFilters() { set({ filters: { ...DEFAULT_FILTERS } }); },
}));
