import { useQuery, useQueryClient, queryOptions } from '@tanstack/react-query';
import { isOnline } from './net';
import { usersSearchApi } from '../../common/api/usersApi';
import { companiesByIdsApi } from '../../common/api/companiesApi';
import { toUserItemVM } from './mappers/dtoToVm';
import { searchUsersOfflineJoin } from './sqlite';
import { SyncService } from './services/SyncService';
import type { FetchParams, FetchResult, Filters } from './repository/types';

const sync = new SyncService();

// --- Persisted params via React Query ---
export type UsersParams = FetchParams;

export const DEFAULT_FILTERS: Filters = {
  name: '', address: '', email: '', companyId: null, sortBy: 'name', sortOrder: 'asc',
};

export const DEFAULT_PARAMS: UsersParams = {
  page: 1,
  perPage: 20,
  filters: { ...DEFAULT_FILTERS },
};

export function useUsersParams() {
  return useQuery({
    queryKey: ['usersParams'],
    initialData: DEFAULT_PARAMS,
    staleTime: Infinity,
    gcTime: Infinity,
  });
}

export function useUpdateUsersParams() {
  const qc = useQueryClient();
  return (updater: (old: UsersParams) => UsersParams) => {
    const old = qc.getQueryData<UsersParams>(['usersParams']) ?? DEFAULT_PARAMS;
    const next = updater(old);
    qc.setQueryData(['usersParams'], next);
  };
}

// --- Hybrid data query (API if online, SQLite if offline) ---
async function hybridFetch(params: UsersParams, signal?: AbortSignal): Promise<FetchResult> {
  if (!(await isOnline())) {
    return searchUsersOfflineJoin(params);
  }
  // Online: call API(s)
  const { items: users, total } = await usersSearchApi({
    page: params.page,
    perPage: params.perPage,
    filters: {
      name: params.filters.name || undefined,
      address: params.filters.address || undefined,
      email: params.filters.email || undefined,
      companyId: params.filters.companyId ?? undefined,
      sortBy: params.filters.sortBy,
      sortOrder: params.filters.sortOrder,
    },
  }, signal);

  const companyIds = Array.from(new Set(users.map(u => u.companyId)));
  const companies = companyIds.length ? await companiesByIdsApi({ ids: companyIds }, signal) : [];
  // fire-and-forget sync
  sync.syncOnce().catch(() => {});

  return { items: toUserItemVM(users, companies), total };
}

export function getUsersQueryOptions(params: UsersParams) {
  return queryOptions<FetchResult>({
    queryKey: ['users', params],
    queryFn: ({ signal }) => hybridFetch(params, signal),
    keepPreviousData: true,
  });
}

export function useUsersData(params: UsersParams) {
  return useQuery(getUsersQueryOptions(params));
}
