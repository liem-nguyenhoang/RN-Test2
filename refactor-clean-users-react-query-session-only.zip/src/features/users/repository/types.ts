export type SortBy = 'name' | 'address' | 'company';
export type SortOrder = 'asc' | 'desc';

export type Filters = {
  name: string;
  address: string;
  email: string;
  companyId: number | null;
  sortBy: SortBy;
  sortOrder: SortOrder;
};

export type UserItemVM = {
  id: number;
  name: string;
  email: string;
  address: string;
  companyId: number;
  companyName: string;
};

export type FetchParams = { page: number; perPage: number; filters: Filters };
export type FetchResult = { items: UserItemVM[]; total: number };
