import type { UserItemVM } from '../repository/types';
import type { UserRowDto } from '../../../common/api/usersApi';
import type { CompanyRowDto } from '../../../common/api/companiesApi';

export function toUserItemVM(users: UserRowDto[], companies: CompanyRowDto[]): UserItemVM[] {
  const cmap = new Map(companies.map(c => [c.id, c.name]));
  return users.map(u => ({
    id: u.id,
    name: u.name,
    email: u.email,
    address: u.address,
    companyId: u.companyId,
    companyName: cmap.get(u.companyId) ?? '(Unknown)',
  }));
}
