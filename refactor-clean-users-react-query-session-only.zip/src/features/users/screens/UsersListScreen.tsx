import React, { useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, Modal, TextInput } from 'react-native';
import { useUsersParams, useUpdateUsersParams, useUsersData, DEFAULT_FILTERS } from '../queries';

export function UsersListScreen() {
  const { data: params } = useUsersParams();
  const setParams = useUpdateUsersParams();

  const { data, isFetching, error, refetch } = useUsersData(params!);

  // Demo: simple inline "modal" filter state (could be separate component)
  const [filterOpen, setFilterOpen] = React.useState(false);
  const [localFilters, setLocalFilters] = React.useState(params!.filters);

  useEffect(() => {
    // whenever params change from persistence, ensure local modal reflects it
    setLocalFilters(params!.filters);
  }, [params]);

  const onApplyFilters = () => {
    setParams((old) => ({ ...old, page: 1, filters: { ...localFilters } }));
    setFilterOpen(false);
  };

  const onClearFilters = () => {
    setLocalFilters(DEFAULT_FILTERS);
    setParams((old) => ({ ...old, page: 1, filters: { ...DEFAULT_FILTERS } }));
  };

  const setPerPage = (n: number) => setParams((old) => ({ ...old, perPage: n, page: 1 }));
  const nextPage  = () => setParams((old) => ({ ...old, page: old.page + 1 }));
  const prevPage  = () => setParams((old) => ({ ...old, page: Math.max(1, old.page - 1) }));

  const total = data?.total ?? 0;
  const items = data?.items ?? [];
  const { page, perPage } = params!;
  const last = Math.max(1, Math.ceil(total / perPage));

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={{ fontSize: 18, fontWeight: '600' }}>Users ({total})</Text>
        <TouchableOpacity onPress={() => setFilterOpen(true)} style={{ padding: 8, backgroundColor: '#eee', borderRadius: 6 }}>
          <Text>Open Filter</Text>
        </TouchableOpacity>
      </View>

      <View style={{ flexDirection: 'row', marginVertical: 8 }}>
        {[20,50,100].map((n) => (
          <TouchableOpacity key={n} onPress={() => setPerPage(n)} style={{ padding: 8, marginRight: 8, borderWidth: 1, borderColor: perPage===n ? '#333' : '#ccc', borderRadius: 6 }}>
            <Text>{n}/page</Text>
          </TouchableOpacity>
        ))}
      </View>

      {isFetching ? <Text>Loading…</Text> : null}
      {error ? <Text style={{ color: 'red' }}>{(error as any)?.message ?? String(error)}</Text> : null}

      <FlatList
        data={items}
        keyExtractor={(it) => String(it.id)}
        renderItem={({ item }) => (
          <View style={{ paddingVertical: 8, borderBottomWidth: 1, borderColor: '#eee' }}>
            <Text style={{ fontWeight: '600' }}>{item.name} — {item.companyName}</Text>
            <Text>{item.email}</Text>
            <Text>{item.address}</Text>
          </View>
        )}
        style={{ flex: 1 }}
      />

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12 }}>
        <TouchableOpacity disabled={page<=1} onPress={prevPage} style={{ padding: 10, backgroundColor: page<=1 ? '#f5f5f5' : '#eee', borderRadius: 6 }}>
          <Text>Previous</Text>
        </TouchableOpacity>
        <Text>Page {page} / {last}</Text>
        <TouchableOpacity disabled={page>=last} onPress={nextPage} style={{ padding: 10, backgroundColor: page>=last ? '#f5f5f5' : '#eee', borderRadius: 6 }}>
          <Text>Next</Text>
        </TouchableOpacity>
      </View>

      {/* Filter Modal */}
      <Modal visible={filterOpen} animationType="slide" onRequestClose={() => setFilterOpen(false)}>
        <View style={{ flex: 1, padding: 16 }}>
          <Text style={{ fontSize: 16, fontWeight: '700', marginBottom: 12 }}>Filters</Text>

          <Text>Name</Text>
          <TextInput value={localFilters.name} onChangeText={(t)=>setLocalFilters(s=>({...s,name:t}))} style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 6, padding: 8, marginBottom: 8 }}/>

          <Text>Address</Text>
          <TextInput value={localFilters.address} onChangeText={(t)=>setLocalFilters(s=>({...s,address:t}))} style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 6, padding: 8, marginBottom: 8 }}/>

          <Text>Email</Text>
          <TextInput value={localFilters.email} onChangeText={(t)=>setLocalFilters(s=>({...s,email:t}))} style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 6, padding: 8, marginBottom: 8 }}/>

          {/* Company dropdown demo (hardcoded) */}
          <Text>Company</Text>
          <View style={{ flexDirection: 'row', marginBottom: 8 }}>
            {[null,1,2,3].map((cid)=> (
              <TouchableOpacity key={String(cid)} onPress={()=>setLocalFilters(s=>({...s, companyId: cid as any}))} style={{ padding: 8, marginRight: 8, borderWidth: 1, borderColor: localFilters.companyId===cid ? '#333' : '#ccc', borderRadius: 6 }}>
                <Text>{cid===null ? 'All' : `Company ${cid}`}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Sort controls */}
          <Text>Sort by</Text>
          <View style={{ flexDirection: 'row', marginBottom: 8 }}>
            {['name','address','company'].map((k)=> (
              <TouchableOpacity key={k} onPress={()=>setLocalFilters(s=>({...s, sortBy: k as any}))} style={{ padding: 8, marginRight: 8, borderWidth: 1, borderColor: localFilters.sortBy===k ? '#333' : '#ccc', borderRadius: 6 }}>
                <Text>{k}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text>Order</Text>
          <View style={{ flexDirection: 'row', marginBottom: 8 }}>
            {['asc','desc'].map((k)=> (
              <TouchableOpacity key={k} onPress={()=>setLocalFilters(s=>({...s, sortOrder: k as any}))} style={{ padding: 8, marginRight: 8, borderWidth: 1, borderColor: localFilters.sortOrder===k ? '#333' : '#ccc', borderRadius: 6 }}>
                <Text>{k.toUpperCase()}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 }}>
            <TouchableOpacity onPress={onClearFilters} style={{ padding: 12, backgroundColor: '#f44336', borderRadius: 8 }}>
              <Text style={{ color: '#fff' }}>Clear</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={onApplyFilters} style={{ padding: 12, backgroundColor: '#2196f3', borderRadius: 8 }}>
              <Text style={{ color: '#fff' }}>Apply</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}
